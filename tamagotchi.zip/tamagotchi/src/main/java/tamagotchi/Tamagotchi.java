package tamagotchi;



public class Tamagotchi {
	
	private String nome;// attributo del nome
	private double gradoSazieta;// attrubuto del grado di sazieta
	private double gradoSoddisfazione;// attrubuto del grado di soddisfazione
	

	private final static String LA_MORTE  =" hai usciso il tamagotchi";// messaggio per l'ucisione del tama 
	private final static String LA_TRESTEZZA  =" sono triste "; // messaggio per  visualizzare che  e' triste 
	
	
	private final static int MAX_BISCOTTI  = 20;//il massimo numero di biscotti da aggiungere
	private final static int MAX_CAREZZE   = 20;//il massimo numero di carezze da aggiungere
	private final static double ABBASAMENTO=0.1;
	private final static int MIN_BISCOTTI  = 0;//il minimo numero di biscotti da aggiungere
	private final static int MIN_CAREZZE   = 0;//il minimo numero di carezze da aggiungere
	
	public String getNome() {
		return nome;
	}// il getter dell'attributo
	public void setNome(String nome) {
		this.nome = nome;
	}//il setter dell'attributo
	public double getGradoSazieta() {
		return gradoSazieta;
	}// il getter dell'attributo
	public void setGradoSazieta(double gradoSazieta) {
		this.gradoSazieta = gradoSazieta;
	}//il setter dell'attributo
	public double getGradoSoddisfazione() {
		return gradoSoddisfazione;
	}// il getter dell'attributo
	public void setGradoSoddisfazione(double gradoSoddisfazione) {
		this.gradoSoddisfazione = gradoSoddisfazione;
	}//il setter dell'attributo
	public Tamagotchi(String nome, double gradoSazieta, double gradoSoddisfazione) {
		this.nome = nome;
		this.gradoSazieta = gradoSazieta;
		this.gradoSoddisfazione = gradoSoddisfazione;
	}
	public void riceviBiscotti(double biscotti) {
	do {
		gradoSoddisfazione=gradoSoddisfazione+biscotti;// la'aggiunta dei biscotti
		gradoSazieta=gradoSazieta-(gradoSazieta*ABBASAMENTO);// per aabbasre del 10% il valore di sazieta'	
	
	}while(biscotti > MAX_BISCOTTI&& biscotti<MIN_BISCOTTI);// controllo addizionale


}
	public void riceviCarezze(double carezze) {
		do {
			
			
			gradoSazieta=gradoSazieta+carezze;// per l'aggiunta delle carezze 
			gradoSoddisfazione=gradoSoddisfazione-(gradoSoddisfazione*ABBASAMENTO);	// per abbassare il grado di soddisfazione
		}while(carezze > MAX_CAREZZE&& carezze< MIN_CAREZZE);// controllo addizionale


	}	
	public void visualizzazione()
	{ System.out.printf("\nil tamagotchi %s \n\nil suo gardo di sazieta' e'%.0f \n\n"
			+ "il grado di soddisfazione e'%.0f\n\n",nome,gradoSazieta,gradoSoddisfazione );
		
		
		
	}
	
public boolean sonoMorto ()
{
	if(gradoSazieta <=0||  gradoSazieta >=100 ||gradoSoddisfazione<=0|| gradoSoddisfazione >=100 )// i controlli in coso della sua morte
		{System.out.println(LA_MORTE);// messaggio per chiarire che e' morto 
		return true;// rende il valore di ritorno vero
	
		}
	return false;//  rende il valore di controllo falso
	
	
	
}
public boolean sonoTriste()
{ if ((gradoSazieta >=80 ||gradoSazieta <=20||gradoSoddisfazione >=80 || gradoSoddisfazione <=20))// i controlli in situazione di trestezza
{System.out.println(LA_TRESTEZZA);;// messaggio per chiarire che e' triste
return true;// rende il valore di ritorno vero

}
return false;//  rende il valore di controllo falso



}
}

